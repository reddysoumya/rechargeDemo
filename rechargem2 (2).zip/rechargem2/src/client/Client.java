package client;

import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import bean.RechargeBean;
import service.IService;
import service.Service;

public class Client {
	static Scanner sc=null;
	static int res=0;
	static IService ser=null;
	static RechargeBean b1=new RechargeBean();
static String rstatus=null;
static boolean r1;
static boolean r2;
static String name=null;
static String number=null;
static int recid=0;
public static void main(String[] args) throws SQLException {
	Logger logger = Logger.getRootLogger();
	PropertyConfigurator.configure("resources/log4j.properties");
	
	sc=new Scanner(System.in);
	ser=new Service();
	System.out.println("***RECHARGE***");
	do {
	System.out.println("enter name");
	name=sc.next();
	 r1=ser.validateName(name);
	}while(r1==false);
	
	do {
	System.out.println("enter mobile number");
	number=sc.next();
	r2=ser.validateNum(number);
	}while(r2==false);
	System.out.println("enter amount");
	int amount=sc.nextInt();
	
	String plantype= ser.validate(amount);
	if(plantype!=null) {
	rstatus="recharged";
	}
	RechargeBean b1=new RechargeBean(name,number,amount,plantype,rstatus);
	
	try {
		res=addDetails(b1);
		
	} catch (SQLException e) {
		logger.error("check once and try again" );
		;
	}
	if(res>0) {
		logger.info("you had recharged with plan "+plantype);
		System.out.println("recharged successfully and recharge_id= "+res);
	}
		else {
			System.out.println("try again");
		}
	}
private static int addDetails(RechargeBean b1) throws SQLException {
	ser=new Service();
	return ser.addDetails(b1);
}
}