package service;

import java.sql.SQLException;

import bean.RechargeBean;

public interface IService {

	int addDetails(RechargeBean b1) throws SQLException;


	String validate(int amount);


	boolean validateName(String name);


	boolean validateNum(String number);

	//int addFinalDetails(RechargeBean b1) throws SQLException;



}
