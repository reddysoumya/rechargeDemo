package service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.RechargeBean;
import dao.IRecDao;
import dao.RecDao;

public class Service implements IService {
IRecDao dao=null;
String plan=null;
String s1=null;
	@Override
	public int addDetails(RechargeBean b1) throws SQLException {
		// TODO Auto-generated method stub
		dao=new RecDao();
	return 	dao.addDetails(b1);
	}
	@Override
	public String validate(int amount) {
		// TODO Auto-generated method stub
		if(amount==99) {
			
			plan = "Rs99"	;
				}
				else if(amount==199){
			 plan="Rs199";
				}
				else if(amount==299) {
				 plan="Rc299";
				}
				else {
					System.out.println("no plan found");
				}
		
			return plan;
	}
	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		Pattern pattern = Pattern.compile("{1}[A-Z][a-z]{1,15}");
		Matcher matcher = pattern.matcher(name);
		if(matcher.matches()) {				
			return true;
	}
		else {
			System.out.println("please enter a valid name");
			return false;
		}
	}
	@Override
	public boolean validateNum(String number) {
		// TODO Auto-generated method stub
		Pattern pattern = Pattern.compile("{1}[7-9][0-9]{9}");
		Matcher matcher = pattern.matcher(number);
		if(matcher.matches()) {				
			return true;}
		else {
			System.out.println("please enter a valid number");
			return false;
		}
		
	}	
	
	
	
}









