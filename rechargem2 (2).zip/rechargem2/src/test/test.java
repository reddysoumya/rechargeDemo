package test;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import bean.RechargeBean;
import dao.IRecDao;
import dao.RecDao;
import util.DBUtil;


public class test {
	IRecDao rdao=null;
	RechargeBean rb=null;
Connection conn=null;
	@Before
	public void init()
	{
		 conn=DBUtil.getDbConnection();
	}
	@Test
	public void checkDbConnectivity()
	{
		
		Assert.assertNotNull(conn);
	}
	
	@After
	public void destroy()
	{
		conn=null;
	}
/*	@Before
	public void init1()
	{
		rdao=new RecDao();
		rb=new RechargeBean();
	}
	@Test
	public void CheckaddDetails() throws SQLException
	{
		String res=rdao.addDetails(rb);
		Assert.assertEquals(33,res);
	}
	
	@After
	public void destroy1()
	{
		rdao=null;
	}*/
}
