package bean;

public class RechargeBean {
private int recid;
private String name;
private String number;
private int amount;
private String plan;
private String date;
private String status;

public RechargeBean() {
	super();
	// TODO Auto-generated constructor stub
}
public int getRecid() {
	return recid;
}
public void setRecid(int recid) {
	this.recid = recid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public String getPlan() {
	return plan;
}
public void setPlan(String plan) {
	this.plan = plan;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}

public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

public RechargeBean(String name, String number, int amount, String plan, String status) {
	super();
	this.name = name;
	this.number = number;
	this.amount = amount;
	this.plan = plan;
	this.status = status;
}
public RechargeBean(int recid, String name, String number, int amount, String plan, String date) {
	super();
	this.recid = recid;
	this.name = name;
	this.number = number;
	this.amount = amount;
	this.plan = plan;
	this.date = date;
}

}
