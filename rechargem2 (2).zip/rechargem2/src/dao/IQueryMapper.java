package dao;

public interface IQueryMapper {

	String rec_insert_qry = "insert into rec values(se1.nextval,?,?,?,?,sysdate,?)";
	String rec_qry = "SELECT se1.currval from dual";

}
