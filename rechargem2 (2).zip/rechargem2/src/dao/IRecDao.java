package dao;

import java.sql.SQLException;

import bean.RechargeBean;

public interface IRecDao {

	int addDetails(RechargeBean b1) throws SQLException;


	//int addFianlDetails(RechargeBean b1) throws SQLException;

}
